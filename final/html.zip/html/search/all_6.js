var searchData=
[
  ['vertex_0',['Vertex',['../class_vertex.html',1,'']]]
];
