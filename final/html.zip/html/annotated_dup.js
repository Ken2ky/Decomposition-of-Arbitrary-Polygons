var annotated_dup =
[
    [ "DCEL", "class_d_c_e_l.html", null ],
    [ "Face", "class_face.html", null ],
    [ "HalfEdge", "class_half_edge.html", null ],
    [ "Vertex", "class_vertex.html", null ]
];